import React from "react";

const HeroSectionskeleton = () => {
  return (
    <div class=" px-4 mx-auto max-w-screen-xl text-center pt-4 lg:pt-8 lg:px-12 my-4">
      <h1 class="bg-gray-300 mb-4 text-3xl font-extrabold tracking-tight leading-none text-gray-300 md:text-3xl lg:text-4xl ">
        Call Girls in Janakpuri & Escorts Profile with Numbers
      </h1>
   
      <div className="h-[146px] text-lg font-normal text-black lg:text-xl sm:px-16 xl:px-28 dark:text-gray-400">
        {" "}
        <p className="h-[65px] bg-gray-300"></p>
      </div>
    </div>
  );
};

export default HeroSectionskeleton;
